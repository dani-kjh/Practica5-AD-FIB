/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.BufferedReader;
//import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Paths;
import java.util.Map.Entry;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.MultiPartFeature;



/**
 *
 * @author alumne
 */
@WebServlet(name = "registrarimagen", urlPatterns = {"/registrarimagen"})
@MultipartConfig
public class registrarimagen extends HttpServlet {

   

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        boolean correctUpload = true;
        try {
            // Obtencion de parametros de la peticion del jsp necesarios para realizar las llamadas al servicio REST
            HttpSession session = request.getSession();
            String nombreUsuarioActual = session.getAttribute("user").toString();
            Part filePart = request.getPart("image"); // Retrieves <input type="file" name="image">
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // MSIE fix.
            InputStream fileContent = filePart.getInputStream();
            
            
            // Inicio de registrar imagen en la base de datos

            String charset = java.nio.charset.StandardCharsets.UTF_8.name();
            String theQueryString="";
            for(Entry<String, String[]> qsParm:request.getParameterMap().entrySet()) {
              theQueryString+="&"+qsParm.getKey()+"="+URLEncoder.encode(request.getParameter(qsParm.getKey()), charset);   
            }
            //Anadimos parametros adicionales que no se pueden obtener con getParameter
            theQueryString+="&creator="+URLEncoder.encode(nombreUsuarioActual,charset);
            theQueryString+="&filename="+URLEncoder.encode(fileName,charset);
            StringBuilder query = new StringBuilder(theQueryString);
            query= query.deleteCharAt(0);
            
            //Preparamos la conexion Http
            URL url = new URL("http://localhost:8080/RestAD/resources/javaee8/register");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Accept-Charset", java.nio.charset.StandardCharsets.UTF_8.name());
            conn.setRequestProperty("Accept", "text/html");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=" + charset);

            // enviamos la peticion al servicio REST via connection OutputStream
            try (OutputStream output = conn.getOutputStream()) {
              output.write(theQueryString.getBytes(java.nio.charset.StandardCharsets.UTF_8.name()));  // this sends the request to the API url
            }
            
            //Obtenemos la respuesta del servicio REST y la escribimos 
            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            PrintWriter writer = response.getWriter();
            String output;
            while ((output = br.readLine()) != null) {
                    writer.println(output);
            }
            
            conn.disconnect();
            //Fin de registrar imagen en la base de datos
            
            uploadImage(fileContent, fileName, writer);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            correctUpload = false;
            response.sendRedirect("error.jsp?tipo=registrarimagen");
        }
        
    }

    private void uploadImage(InputStream fileContent, String fileName, PrintWriter writer) {
        //Inicio de subir la foto a una carpeta del servicio
        
        Client client = ClientBuilder.newBuilder()
                .register(MultiPartFeature.class)
                .build();
        WebTarget t = client.target("http://localhost:8080/RestAD/resources/javaee8/upload");
        
        MultiPart multipartEntity;
        multipartEntity = new FormDataMultiPart()
                .field("file", fileContent, MediaType.APPLICATION_OCTET_STREAM_TYPE)
                .field("fileName", fileName);
        
        try (Response responseA = t.request().post(
                Entity.entity(multipartEntity, multipartEntity.getMediaType()))) {
            writer.println("<br>");
            writer.println(responseA.readEntity(String.class));
        }
        
        //Fin de subir la foto a una carpeta del servicio
    }
    
    

    
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        processRequest(request, response);
         PrintWriter out = response.getWriter();

         
       
         out.println("<html> <body>"
                        + "<br>"
                        + "<a href='registrarimagen.jsp'> Ir a registar imagen </a>"
                        + "<br>"
                        + "<a href='menu.jsp'> Volver al menu</a> "
                        + "<br>"
                        + "</body></html>");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
