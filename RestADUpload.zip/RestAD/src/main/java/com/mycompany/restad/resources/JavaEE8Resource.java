package com.mycompany.restad.resources;

import BaseDatos.ModificacionyConsulta;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

/**
 *
 * @author 
 */
@Path("javaee8")
public class JavaEE8Resource {
    /**
    * POST method to register a new image
* @param title
* @param description
* @param keywords
* @param author
* @param creator
* @param capt_date
   @param filename
* @return
*/
    @Path("register")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED) @Produces(MediaType.TEXT_HTML)
    public String registerImage (@FormParam("title") String title,
                @FormParam("description") String description, 
                @FormParam("keywords") String keywords,
                @FormParam("author") String author,
                @FormParam("creator") String creator,
                @FormParam("capture") String capt_date,
                @FormParam("filename") String filename) throws ClassNotFoundException{
                    ModificacionyConsulta connection = new ModificacionyConsulta();
                    try {
                        Class.forName("org.apache.derby.jdbc.ClientDriver");
                        boolean error = connection.registrarImagen(title, description, keywords, author, creator, capt_date, filename);
                         

                    } catch (Exception e) {
                        System.err.println(e.getMessage());

                    } finally{
                        connection.cerrarconexion();
                    }
                    String result = "La imagen se ha registrado correctamente en la base de datos"; 
                    return result;
            

    }


/**
* POST method to register a new image
* @param title
* @param description
* @param keywords
* @param author
* @param creator
* @param capt_date
* @return
*/
    @Path("modify")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED) @Produces(MediaType.TEXT_HTML)
    public String modifyImage (@FormParam("id") String id, @FormParam("title") String title,
            @FormParam("description") String description, 
            @FormParam("keywords") String keywords, 
            @FormParam("author") String author,
            @FormParam("creator") String creator, 
            @FormParam("capture") String capt_date){
                ModificacionyConsulta connection = new ModificacionyConsulta();
                try {
                    Class.forName("org.apache.derby.jdbc.ClientDriver");
                    int id_ = Integer.parseInt(id);
                    boolean error = connection.updateimagen(title, description, keywords, author, capt_date, id_);


                } catch (Exception e) {
                    System.err.println(e.getMessage());

                } finally{
                    connection.cerrarconexion();
                }
                String result = "La imagen " + id + " se ha modificado correctamente"+ "<form>"
                        + "<input type = 'button' value = 'Go back' onclick= 'history.back()' > "
                        + "</form>"; //ir a listar???
                return result; 
    }
/**   
* POST method to delete an existing image     
* @param id       
* @return
 */  
        @Path("delete")   
        @POST    
        @Consumes(MediaType.APPLICATION_FORM_URLENCODED)    
        @Produces(MediaType.TEXT_HTML)    
        public String deleteImage (@FormParam("id") String id){
            System.out.println(id);
           ModificacionyConsulta connection = new ModificacionyConsulta();
           try {
               connection.eliminarImagen(id);
           } catch (Exception e) {
               System.err.println(e.getMessage());

           } finally{
               connection.cerrarconexion();
           }
           String result = "La imagen " + id + " se ha eliminado correctamente" +"<form>"
                        + "<input type = 'button' value = 'Go back' onclick= 'history.back()' > "
                        + "</form>"; //ir a listar???
           return result;
        }


/**
 * GET method to list images
 * @return
 */
    @Path("list")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String listImages () {
        ModificacionyConsulta con = new ModificacionyConsulta();
        ResultSet rs = con.list();
        String resultat = llistarImatges(rs);
        con.cerrarconexion();
        return resultat;
    }
/**
* GET method to search images by id
* @param id
* @return
*/
    @Path("searchID/{id}")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String searchByID (@PathParam("id") int id)  {
        System.out.println(id);
        ModificacionyConsulta con = new ModificacionyConsulta();
        ResultSet rs = con.searchById(id);
        String resultat = llistarImatges(rs);
        con.cerrarconexion();
        return resultat;
    }
/**
* GET method to search images by title
* @param title
* @return
*/
    @Path("searchTitle/{title}")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String searchByTitle (@PathParam("title") String title) {
        System.out.println(title);
        ModificacionyConsulta con = new ModificacionyConsulta();
        ResultSet rs = con.search(title, "", "", "", "");
        String resultat = llistarImatges(rs);
        con.cerrarconexion();
        return resultat;

    }
/**
* GET method to search images by creation date. DAte format should be yyyy-mm-dd
* @param date
* @return
*/
    @Path("searchCreationDate/{date}")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String searchByCreationDate (@PathParam("date") String date) {
        System.out.println(date);
        ModificacionyConsulta con = new ModificacionyConsulta();
        ResultSet rs = con.search("", "", "", "", date);
        String resultat = llistarImatges(rs);
        con.cerrarconexion();
        return resultat;

    }
/**
* GET method to search images by author
* @param author
* @return
*/
    @Path("searchAuthor/{author}")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String searchByAuthor (@PathParam("author") String author) {
        System.out.println(author);
        ModificacionyConsulta con = new ModificacionyConsulta();
        ResultSet rs = con.search("", "", author, "", "");
        String resultat = llistarImatges(rs);
        con.cerrarconexion();
        return resultat;

    }
/**
* GET method to search images by keyword
* @param keywords
* @return
*/
    @Path("searchKeywords/{keywords}")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String searchByKeywords (@PathParam("keywords") String keywords) {
        System.out.println(keywords);
         ModificacionyConsulta con = new ModificacionyConsulta();
        ResultSet rs = con.search("", "", "", keywords, "");
        String resultat = llistarImatges(rs);
        con.cerrarconexion();
        return resultat;

    }
    
    @POST
    @Path("/upload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadFile(
		@FormDataParam("file") InputStream uploadedInputStream,
		@FormDataParam("fileName") String fileName) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy_HH-mm-ss");  
                LocalDateTime now = LocalDateTime.now();
                String filename = dtf.format(now);
		String uploadedFileLocation = "/home/alumne/NetBeansProjects/RestAD/src/main/files/" + fileName;

		// save it
		writeToFile(uploadedInputStream, uploadedFileLocation);

		String output = "La imagen se ha guardado correctamente en el directorio del servidor";

		return Response.status(200).entity(output).build();

	}

	// save uploaded file to new location
	private void writeToFile(InputStream uploadedInputStream,
		String uploadedFileLocation) {

		try {
			OutputStream out = new FileOutputStream(new File(
					uploadedFileLocation));
			int read = 0;
			byte[] bytes = new byte[1024];

			out = new FileOutputStream(new File(uploadedFileLocation));
			while ((read = uploadedInputStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			out.flush();
			out.close();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
        
  
  @POST
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED) 
  @Produces(MediaType.APPLICATION_OCTET_STREAM)
  @Path("/download")
  public Response download(@FormParam("filename") String filename){
    File file = new File("/home/alumne/NetBeansProjects/RestAD/src/main/files/"+ filename + "/");
    return Response.status(200)
            .entity(file)
        .header("Content-Disposition", "attachment; filename=" + file.getName())
        .build();
  }

    private String llistarImatges(ResultSet rs) {
        boolean primeraFila = true;
            String result = "";
        try {
            
            while(rs.next()){
                if(primeraFila){
                    primeraFila = false;
                    result += "";
                }
                result += "<ul>" 
                        + "<li> " + rs.getInt("id") + "</li>"
                        +"<li> Titulo:" + rs.getString("title") + "</li>"
                        + "<li> Fecha de captura:" + rs.getString("capture_date") + "</li>"
                        +"<li> Descripcion:" + rs.getString("description") + "</li>"
                        +"<li> Keywords:" + rs.getString("keywords") + "</li>"
                        +"<li> Autor:" + rs.getString("author") + "</li>"
                        + "</ul>" 
                        + "<form action='http://localhost:8080/RestAD/resources/javaee8/delete' method = 'POST'>"
                        + "<input type = 'hidden' name = 'id' value ='"+ Integer.toString(rs.getInt("id")) + "'>"
                        + "<button type = 'submit'> Eliminar </button>"
                        + "</form>"
                        +"<form action='http://localhost:8080/RestAD/resources/javaee8/download' method = 'POST'>"
                        + "<input type = 'hidden' name = 'filename' value ='"+ rs.getString("filename") + "'>"
                        + "<button type = 'submit'> Descargar </button>"
                        + "</form>"
                        + "<br>";
                        
                       
            }
        } catch (SQLException ex) {
            Logger.getLogger(JavaEE8Resource.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally {
            result +=  "<form>"
                        + "<input type = 'button' value = 'Go back' onclick= 'history.back()' > "
                        + "</form>";
            return result;
        }
    }
    
    
    
}
