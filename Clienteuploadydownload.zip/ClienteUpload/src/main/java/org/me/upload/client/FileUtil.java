/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.upload.client;

import java.io.InputStream;
import javax.servlet.http.Part;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.Part;
/**
 *
 * @author alumne
 */
class FileUtil {

    static String getFilename(Part filePart) {
        for (String cd : filePart.getHeader("content-disposition").split(";")) {
			if (cd.trim().startsWith("filename")) {
				String filename = cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
				return filename.substring(filename.lastIndexOf('/') + 1).substring(filename.lastIndexOf('\\') + 1); // MSIE
																													// fix.
			}
		}
		return null;
    }

    static byte[] getFileContent(InputStream inputStream) {
        try {

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int reads = inputStream.read();

			while (reads != -1) {
				baos.write(reads);
				reads = inputStream.read();
			}

			return baos.toByteArray();

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
    }
    
}
