/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.fileupload;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author alumne
 */
class FileUtils {

    static boolean saveFile(final String path, String fileName, InputStream fileContent) throws IOException{
        boolean correctUpload = true;
        OutputStream out = null;
        InputStream filecontent = null;
        try{
            out = new FileOutputStream(new File(path + File.separator
                    + fileName));
            
          
            int read = 0;
            final byte[] bytes = new byte[1024];
            
            while ((read = fileContent.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
           
     
            
        }catch (FileNotFoundException fne) {
            correctUpload = false;
        }
        return correctUpload;
    }
    
}
