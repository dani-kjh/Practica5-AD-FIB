/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.upload;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.Path;

/**
 *
 * @author alumne
 */
class FileUtils {

    static boolean saveFile(byte[] fileContent, String fileName) {
        OutputStream outputStream = null;

		try {
			File file = new File("/home/alumne/NetBeansProjects/ClienteWeb/src/main/webapp/imagenes" + File.separator + fileName);
			outputStream = new FileOutputStream(file);
			outputStream.write(fileContent);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (outputStream != null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return false;
    }

    static byte[] recoverFile(String fileName) {
        byte[] data = null;
        
        try {
            data = Files.readAllBytes(Paths.get("/home/alumne/NetBeansProjects/ClienteWeb/src/main/webapp/imagenes/"+fileName+"/"));
        } catch (IOException ex) {
            Logger.getLogger(FileUtils.class.getName()).log(Level.SEVERE, null, ex);
        }
        return data;
    
    }
    
}
