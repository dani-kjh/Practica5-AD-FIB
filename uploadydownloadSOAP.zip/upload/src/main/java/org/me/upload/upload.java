/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.upload;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author alumne
 */
@WebService(serviceName = "upload")
public class upload {

    /**
     * Web service operation
     * @param fileName
     * @param fileContent
     * @return 
     */
    @WebMethod(operationName = "sendFile")
    public String sendFile(@WebParam(name = "fileName") String fileName, @WebParam(name = "fileContent") byte[] fileContent) {
        boolean response = FileUtils.saveFile(fileContent, fileName);

		if (response) {
			return "File successfully received and saved to disk!";
		}

	return "OOPs! some error occurred.";
    }

    /**
     * Web service operation
     * @param fileName
     * @return 
     */
    @WebMethod(operationName = "getFile")
    public byte[] getFile(@WebParam(name = "fileName") String fileName) {
        byte[] res = FileUtils.recoverFile(fileName);
        return res;
    }
}
